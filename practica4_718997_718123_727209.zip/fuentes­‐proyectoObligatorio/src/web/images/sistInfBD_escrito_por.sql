INSERT INTO sistInfBD.escrito_por (libro, autor) VALUES ('1', 'Autor2');
INSERT INTO sistInfBD.escrito_por (libro, autor) VALUES ('2', 'Autor3');
INSERT INTO sistInfBD.escrito_por (libro, autor) VALUES ('3', 'Autor2');