INSERT INTO sistInfBD.visita (usuario, libro, fecha) VALUES ('abel1', '3', '2017-11-17');
INSERT INTO sistInfBD.visita (usuario, libro, fecha) VALUES ('user1', '1', '2017-11-17');
INSERT INTO sistInfBD.visita (usuario, libro, fecha) VALUES ('user1', '2', '2017-11-17');
INSERT INTO sistInfBD.visita (usuario, libro, fecha) VALUES ('user1', '3', '2017-11-17');
INSERT INTO sistInfBD.visita (usuario, libro, fecha) VALUES ('user1', '4', '2017-11-17');
INSERT INTO sistInfBD.visita (usuario, libro, fecha) VALUES ('user1', '5', '2017-11-17');
INSERT INTO sistInfBD.visita (usuario, libro, fecha) VALUES ('user1', '7', '2017-11-17');