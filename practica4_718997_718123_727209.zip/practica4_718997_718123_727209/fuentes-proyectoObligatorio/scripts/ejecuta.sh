java -cp ../lib/lucene-core-4.0.0.jar:../lib/lucene-analyzers-common-4.0.0.jar:../lib/lucene-queryparser-4.0.0.jar:../bin/ sistemasinformacion.practica3.Apartado21
java -cp ../lib/lucene-core-4.0.0.jar:../lib/lucene-analyzers-common-4.0.0.jar:../lib/lucene-queryparser-4.0.0.jar:../bin/ sistemasinformacion.practica3.Apartado22_CreadorIndice
java -cp ../lib/lucenre-4.0.0.jar:../lib/lucene-analyzers-common-4.0.0.jar:../lib/lucene-queryparser-4.0.0.jar:../bin/ sistemasinformacion.practica3.Apartado22_Buscador
