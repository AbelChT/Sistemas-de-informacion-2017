INSERT INTO sistInfBD.genero (nombre) VALUES ('ciencia');
INSERT INTO sistInfBD.genero (nombre) VALUES ('deporte');
INSERT INTO sistInfBD.genero (nombre) VALUES ('idiomas');
INSERT INTO sistInfBD.genero (nombre) VALUES ('infantiles');
INSERT INTO sistInfBD.genero (nombre) VALUES ('novela');