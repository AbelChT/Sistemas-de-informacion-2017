package modelo.datos.VO;

public class GeneroVO {
    private String nombre;

    public GeneroVO(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}