INSERT INTO sistInfBD.autor (nombre_completo, pais_de_nacimiento, descripcion) VALUES ('Autor2', 'Esp', 'Descrp2');
INSERT INTO sistInfBD.autor (nombre_completo, pais_de_nacimiento, descripcion) VALUES ('Autor3', 'Esp', 'Desc3');
INSERT INTO sistInfBD.autor (nombre_completo, pais_de_nacimiento, descripcion) VALUES ('Santolaia', 'Esp', 'Descr');